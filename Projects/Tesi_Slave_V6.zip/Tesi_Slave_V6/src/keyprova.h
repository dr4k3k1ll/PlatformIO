#ifndef _SECRET_H_
#define _SECRET_H_

#define MY_WIFI_SSID "TIM-95654790"
#define MY_WIFI_PASS "5HfmCdYa3hDLfkr2"

#define MY_WIFI_SSID_2 "iPhone di Michele Andrea"
#define MY_WIFI_PASS_2 "dromedario"

#define MY_WIFI_SSID_3 "ESP_32_CAM_AP"
#define MY_WIFI_PASS_3 "Passw0rd"

#endif